このディレクトリーに適当なファイル名でプロパティー・ファイル (.properties) を
作成することで、オリジナルの訳を追加することができます。
UTF-8 で native2ascii 不要です。

readme/readme_pleiades.txt の
Pleiades 起動オプションの debug を参照してください。
