package create.enums;

/*	改訂履歴
 * ----------- ------- --------------- ----------------
 * Date			Seq		Editor			Description
 * ----------- ------- --------------- ----------------
 * 2023-03-01	r1.00	T.Kudou			新規作成
 * 
 */

public class CreateQue {
	
	protected QueAns createQue(int num) {

		QueAns newQue = new QueAns(0, null, null, null, null, null, 0, 1);
		
		if(num == 1) {
			newQue.number = 1;
			
			newQue.dispQue = "<html><body>ブラウザとWebサーバ間の通信プロトコルを，HTTPからHTTPSに変更した。これによって実現できることとして，適切なものはどれか。</html></body>。";
			
			newQue.dispAns1 = new DispAns(1, "クライアントPCとWebサーバ間の通信速度の向上");
			
			newQue.dispAns2 = new DispAns(2, "コンピュータウイルス感染の防止");
			
			newQue.dispAns3 = new DispAns(3, "通信の機密性の確保");
			
			newQue.dispAns4 = new DispAns(4, "ブラウザの表示速度の向上");
			
			newQue.ans = 3;
			
			newQue.dispTyp = 2;
			
			return newQue;
			
		} else if(num == 2) {
			
			newQue.number = 2;
			
			newQue.dispQue = "<html><body>ネットワークにおいて，外部からの不正アクセスを防ぐために内部ネットワークと外部ネットワークの間に置かれるものはどれか。</html></body>。";
			
			newQue.dispAns1 = new DispAns(1, "DNSサーバ");
			
			newQue.dispAns2 = new DispAns(2, "サーチエンジン");
			
			newQue.dispAns3 = new DispAns(3, "スイッチングハブ");
			
			newQue.dispAns4 = new DispAns(4, "ファイアウォール");
			
			newQue.ans = 4;
			
			newQue.dispTyp = 1;
			
			return newQue;
			
		} else if(num == 3) {
			
			newQue.number = 3;
			
			newQue.dispQue = "<html><body>A社では営業部員の行動予定を把握したい。このとき利用するソフトウェアとして，最も適切なものはどれか。</html></body>。";
			
			newQue.dispAns1 = new DispAns(1, "CRMソフトウェア");
			
			newQue.dispAns2 = new DispAns(2, "ERPソフトウェア");
			
			newQue.dispAns3 = new DispAns(3, "SCMソフトウェア");
			
			newQue.dispAns4 = new DispAns(4, "グループウェア");
			
			newQue.ans = 4;
			
			newQue.dispTyp = 1;
			
			return newQue;
			
		} else if(num == 4) {
			
			newQue.number = 4;
			
			newQue.dispQue = "<html><body>ソーシャルエンジニアリングによる被害に結びつきやすい状況はどれか。</html></body>。";
			
			newQue.dispAns1 = new DispAns(1, "運用担当者のセキュリティ意識が低い。");
			
			newQue.dispAns2 = new DispAns(2, "サーバ室の天井の防水対策が行われていない。");
			
			newQue.dispAns3 = new DispAns(3, "サーバへのアクセス制御が行われていない。");
			
			newQue.dispAns4 = new DispAns(4, "通信経路が暗号化されていない。");
			
			newQue.ans = 1;
			
			newQue.dispTyp = 2;
			
			return newQue;
			
		} else if(num == 5) {
			
			newQue.number = 5;
			
			newQue.dispQue = "<html><body>最大32文字までの英数字が設定でき，複数のアクセスポイントを設置したネットワークに対しても使用できる，無線LANのネットワークを識別するものはどれか。</html></body>。";
			
			newQue.dispAns1 = new DispAns(1, "ESSID");
			
			newQue.dispAns2 = new DispAns(2, "IPアドレス");
			
			newQue.dispAns3 = new DispAns(3, "MACアドレス");
			
			newQue.dispAns4 = new DispAns(4, "RFID");
			
			newQue.ans = 1;
			
			newQue.dispTyp = 1;
			
			return newQue;
			
		} else if(num == 6) {
			
			newQue.number = 6;
			
			newQue.dispQue = "<html><body>情報セキュリティの基本方針に関する記述のうち，適切なものはどれか。</html></body>。";
			
			newQue.dispAns1 = new DispAns(1, "機密情報の漏えいを防ぐために，経営上の機密事項とする。");
			
			newQue.dispAns2 = new DispAns(2, "情報セキュリティに対する組織の取組みを示すもので，経営層が承認する。");
			
			newQue.dispAns3 = new DispAns(3, "情報セキュリティの対策基準に基づいて策定する。");
			
			newQue.dispAns4 = new DispAns(4, "パスワードの管理方法や文書の保存方法を具体的に規定する。");
			
			newQue.ans = 2;
			
			newQue.dispTyp = 2;
			
			return newQue;
			
		} else if(num == 7) {
			
			newQue.number = 7;
			
			newQue.dispQue = "<html><body>情報セキュリティの基本方針に関する記述のうち，適切なものはどれか。</html></body>。";
			
			newQue.dispAns1 = new DispAns(1, "アクセスタイム");
			
			newQue.dispAns2 = new DispAns(2, "スループット");
			
			newQue.dispAns3 = new DispAns(3, "タイムスタンプ");
			
			newQue.dispAns4 = new DispAns(4, "レスポンスタイム");
			
			newQue.ans = 2;
			
			newQue.dispTyp = 1;
			
			return newQue;
			
		} else if(num == 8) {
			
			newQue.number = 8;
			
			newQue.dispQue = "<html><body>次のうち，無線LANで使用される暗号化規格はどれか。</html></body>。";
			
			newQue.dispAns1 = new DispAns(1, "cookie");
			
			newQue.dispAns2 = new DispAns(2, "ESSID");
			
			newQue.dispAns3 = new DispAns(3, "MIME");
			
			newQue.dispAns4 = new DispAns(4, "WPA2");
			
			newQue.ans = 4;
			
			newQue.dispTyp = 1;
			
			return newQue;
			
		} else if(num == 9) {
			
			newQue.number = 9;
			
			newQue.dispQue = "<html><body>拡張子\"avi\"が付くファイルが扱う対象として，最も適切なものはどれか。</html></body>。";
			
			newQue.dispAns1 = new DispAns(1, "音声");
			
			newQue.dispAns2 = new DispAns(2, "静止画");
			
			newQue.dispAns3 = new DispAns(3, "動画");
			
			newQue.dispAns4 = new DispAns(4, "文書");
			
			newQue.ans = 3;
			
			newQue.dispTyp = 1;
			
			return newQue;
			
		} else if(num == 10) {
			
			newQue.number = 10;
			
			newQue.dispQue = "<html><body>金融システムの口座振替では，振替元の口座からの出金処理と振替先の口座への入金処理について，両方の処理が実行されるか，"
					+ "両方とも実行されないかのどちらかであることを保証することによってデータベースの整合性を保っている。データベースに対するこのような一連の処理をトランザクションとして扱い，"
					+ "矛盾なく処理が完了したときに，データベースの更新内容を確定することを何というか。</html></body>。";
			
			newQue.dispAns1 = new DispAns(1, "コミット");
			
			newQue.dispAns2 = new DispAns(2, "スキーマ");
			
			newQue.dispAns3 = new DispAns(3, "ロールフォワード");
			
			newQue.dispAns4 = new DispAns(4, "ロック");
			
			newQue.ans = 1;
			
			newQue.dispTyp = 1;
			
			return newQue;
			
		} else {
			return newQue;
		}
		
		
	}

}
