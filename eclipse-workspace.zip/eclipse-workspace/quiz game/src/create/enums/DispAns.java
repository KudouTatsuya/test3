package create.enums;

/*	改訂履歴
 * ----------- ------- --------------- ----------------
 * Date			Seq		Editor			Description
 * ----------- ------- --------------- ----------------
 * 2023-03-01	r1.00	T.Kudou			新規作成
 * 
 * 
 * 
 */

public class DispAns {
	
	// 番号 
	int number;
	
	// 表示解答
	String dispAns;
	
	public DispAns(int number, String dispAns){
		this.number = number;
		this.dispAns = dispAns;
	}
	
	  /**
	   * 番号を取得
	   *
	   * @return 問題番号
	   */
	  public int getNumber() {
	    return this.number;
	  }

	  /**
	   * 表示解答を取得
	   *
	   * @return 表示解答
	   */
	  public String getDispAns() {
	    return this.dispAns;
	  }
	
}
