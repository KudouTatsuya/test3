package create.enums;

/*	改訂履歴
 * ----------- ------- --------------- ----------------
 * Date			Seq		Editor			Description
 * ----------- ------- --------------- ----------------
 * 2022-09-06	r1.00	T.Kudou			新規作成
 * 
 */

public enum Status {

	/** 待ち状態 */
	Wait,
	
	/** 結果発表中 */
	Done
	
}
