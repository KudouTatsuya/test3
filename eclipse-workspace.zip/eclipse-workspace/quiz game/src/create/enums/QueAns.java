package create.enums;

import java.util.Random;

/*	改訂履歴
 * ----------- ------- --------------- ----------------
 * Date			Seq		Editor			Description
 * ----------- ------- --------------- ----------------
 * 2022-09-06	r1.00	T.Kudou			新規作成
 * 
 * 
 * 
 */

public class QueAns {
	
		// 問題番号 
		int number;
		
		// 表示問題
		String dispQue;
		
		// 表示解答１
		DispAns dispAns1;
		
		// 表示解答２
		DispAns dispAns2;

		// 表示解答３
		DispAns dispAns3;
		
		// 表示解答４
		DispAns dispAns4;
		
		// 正答
		int ans;
		
		// 表示形式
		int dispTyp;
		
		public QueAns(int number, String dispQue, DispAns dispAns1, DispAns dispAns2, 
				DispAns dispAns3, DispAns dispAns4, int ans, int dispTyp){
			
			this.number = number;
			this.dispQue = dispQue;
			this.dispAns1 = dispAns1;
			this.dispAns2 = dispAns2;
			this.dispAns3 = dispAns3;
			this.dispAns4 = dispAns4;
			this.ans = ans;
			this.dispTyp = dispTyp;
			
		}
		
		  /**
		   * ランダムに問題を生成
		   *
		   * @return ランダムに生成した問題
		   */
		  public static QueAns getQuestion() {
		    Random rand = new Random();
		    int num = rand.nextInt(10);
		    CreateQue crtQue = new CreateQue();
			QueAns queAns =  crtQue.createQue(num + 1);
		    return queAns;
		  }
		
		  /**
		   * 問題番号を取得
		   *
		   * @return 問題番号
		   */
		  public int getNumber() {
		    return this.number;
		  }

		  /**
		   * 表示問題を取得
		   *
		   * @return 表示問題
		   */
		  public String getDispQue() {
		    return this.dispQue;
		  }

		  /**
		   * 表示解答１を取得
		   *
		   * @return 表示解答１
		   */
		  public DispAns getDispAns1() {
		    return this.dispAns1;
		  }
		  
		  /**
		   * 表示解答２を取得
		   *
		   * @return 表示解答２
		   */
		  public DispAns getDispAns2() {
		    return this.dispAns2;
		  }
		  
		  /**
		   * 表示解答３を取得
		   *
		   * @return 表示解答３
		   */
		  public DispAns getDispAns3() {
		    return this.dispAns3;
		  }
		  
		  /**
		   * 表示解答４を取得
		   *
		   * @return 表示解答４
		   */
		  public DispAns getDispAns4() {
		    return this.dispAns4;
		  }
		  
		  /**
		   * 正答を取得
		   *
		   * @return 正答
		   */
		  public int getAns() {
		    return this.ans;
		  }
		  
		  /**
		   * 表示形式を取得
		   *
		   * @return 表示形式
		   */
		  public int getDispTyp() {
		    return this.dispTyp;
		  }

}
