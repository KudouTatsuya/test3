package create.window;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;

import javax.swing.*;
import create.enums.Status;
import create.enums.QueAns;
import create.enums.DispAns;

/*	改訂履歴
 * ----------- ------- --------------- ----------------
 * Date			Seq		Editor			Description
 * ----------- ------- --------------- ----------------
 * 2023-03-01	r1.00	T.Kudou			新規作成
 * 
 */

/*
 * ゲームのメイン画面
 */
public class MainWindow {
	
	/**
	 * ゲームを表示するフレーム
	 */
	private JFrame frame;
	
	/**
	 * コンポーネントペイン
	 */
	private Container pane;
	
	/**
	 * ゲームを表示する画面
	 */
	private JPanel canvas;
	
	/**
	 * タイトルを表示するラベル
	 */
	private JLabel titleLabel;
	
	/**
	 * スタートボタン
	 */
	private JButton startButton;
	
	/**
	 * 出題問題
	 */
    private QueAns question;
	
	/**
	 * 問題を表示するラベル
	 */
	private JLabel questionLabel;
	
	/**
	 * 解答１のボタン
	 */
	private JButton ans1Button;
	
	/**
	 * 解答２のボタン
	 */
	private JButton ans2Button;
	
	/**
	 * 解答３のボタン
	 */
	private JButton ans3Button;
	
	/**
	 * 解答４のボタン
	 */
	private JButton ans4Button;
	
	/**
	 * 答えを表示するラベル
	 */
	private JLabel anserLabel;
	
	/**
	 * 次へ行くボタン
	 */
	private JButton nextButton;
	
	/**
	 * 正解表示ボタン
	 */
	private JButton anserButton;
	
	/**
	 * プレイ状況のステータス
	 */
	private Status playState;
	
	/**
	 * 	出題した問題番号を記録するリスト
	 */
	private List<Integer> list = new ArrayList<>();
	
	/**
	 * 上限出題数
	 */
	private final int maxNumQue = 5;
	
	/**
	 * 正答数
	 */
	private int numAns = 0;
	
	/**
	 * 結果を表示するラベル
	 */
	private JLabel rsltLabel;
	
	/**
	 * リトライボタン
	 */
	private JButton retryButton;
	
	
	
	public MainWindow() {
		//　画面生成
		frame = new JFrame("アイパスクイズゲーム！");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// 画面サイズを指定
		frame.setBounds(200, 200, 800, 500);
		
		// コンポーネントペインを取得する。
		pane = frame.getContentPane();
		
		// このcanvasに対して、ボタンやラベルを配置していく。
		canvas = new JPanel();
		// 自由レイアウトに変更する。
		canvas.setLayout(null);
		
		// タイトルを表示する。
		titleLabel = new JLabel(String.format("I PASS QUIZ"));
		titleLabel.setHorizontalAlignment(JLabel.CENTER);
		titleLabel.setFont(new Font("Century", Font.ITALIC, 100));
		titleLabel.setBounds(20, 60, 750, 100);
		canvas.add(titleLabel);
		
		startButton = new JButton("GAME START");
		startButton.setFont(new Font("Century", Font.ITALIC, 20));
		startButton.setBounds(250, 200, 250, 40);
		startButton.addActionListener((e) -> selectStart());
		canvas.add(startButton);
		
		// 画面にcanvasを追加
		pane.add(canvas);

	}
	
	/**
	 * * 画面表示
	 */
	public void show() {
		init();
		frame.setVisible(true);
	}
	  
	/**
	 * ゲームの初期化
	 */
	public void init() {
		// 待ち状態にする。
		playState = Status.Wait;
	}
	  
	/**
	 * 出題処理
	 */
	public void proposingQuestion(JPanel canvas, Container pane) {
		// 表示する問題を取得する。
		boolean newQueFlg = false;
		while(!newQueFlg) {
			question = QueAns.getQuestion();
			if(!list.contains(question.getNumber())) {
				newQueFlg = true;
			}
		}
			
		list.add(question.getNumber());
			
		// 問題を表示するラベルの設定をする。
		questionLabel = new JLabel(question.getDispQue());
		questionLabel.setFont(new Font("Meiryo UI", Font.BOLD, 13));
		questionLabel.setBounds(20, 20, 750, 50);
		canvas.add(questionLabel);
			
		// 答えを表示するラベルの設定をする。
		anserLabel = new JLabel("");
		anserLabel.setFont(new Font("Meiryo UI", Font.BOLD, 15));
		anserLabel.setBounds(50, 310, 650, 50);
		canvas.add(anserLabel);
		
		// -----------------
		// ボタンを作成する
		// -----------------
		
		// 問題ごとの表示形式によって解答ボタンの配置を変更する。
		if(question.getDispTyp() == 2) {
			
			// 表示形式 = 2の場合、解答ボタンを4行で表示する。
			ans1Button = new JButton("１．" + question.getDispAns1().getDispAns());
			ans1Button.setHorizontalAlignment(JButton.LEFT);
			ans1Button.setFont(new Font("Meiryo UI", Font.BOLD, 13));
			ans1Button.setBounds(30, 100, 700, 40);
			ans1Button.addActionListener((e) -> selectAns(question.getDispAns1(), question));
			canvas.add(ans1Button);
			
			ans2Button = new JButton("２．" + question.getDispAns2().getDispAns());
			ans2Button.setHorizontalAlignment(JButton.LEFT);
			ans2Button.setFont(new Font("Meiryo UI", Font.BOLD, 13));
			ans2Button.setBounds(30, 150, 700, 40);
			ans2Button.addActionListener((e) -> selectAns(question.getDispAns2(), question));
			canvas.add(ans2Button);
			
			ans3Button = new JButton("３．" + question.getDispAns3().getDispAns());
			ans3Button.setHorizontalAlignment(JButton.LEFT);
			ans3Button.setFont(new Font("Meiryo UI", Font.BOLD, 13));
			ans3Button.setBounds(30, 200, 700, 40);
			ans3Button.addActionListener((e) -> selectAns(question.getDispAns3(), question));
			canvas.add(ans3Button);
			
			ans4Button = new JButton("４．" + question.getDispAns4().getDispAns());
			ans4Button.setHorizontalAlignment(JButton.LEFT);
			ans4Button.setFont(new Font("Meiryo UI", Font.BOLD, 13));
			ans4Button.setBounds(30, 250, 700, 40);
			ans4Button.addActionListener((e) -> selectAns(question.getDispAns4(), question));
			canvas.add(ans4Button);
			
		}else {
			
			// それ以外の場合、解答ボタンを2行で表示する。
			ans1Button = new JButton("１．" + question.getDispAns1().getDispAns());
			ans1Button.setHorizontalAlignment(JButton.LEFT);
			ans1Button.setFont(new Font("Meiryo UI", Font.BOLD, 13));
			ans1Button.setBounds(50, 100, 250, 40);
			ans1Button.addActionListener((e) -> selectAns(question.getDispAns1(), question));
			canvas.add(ans1Button);
			
			ans2Button = new JButton("２．" + question.getDispAns2().getDispAns());
			ans2Button.setHorizontalAlignment(JButton.LEFT);
			ans2Button.setFont(new Font("Meiryo UI", Font.BOLD, 13));
			ans2Button.setBounds(350, 100, 250, 40);
			ans2Button.addActionListener((e) -> selectAns(question.getDispAns2(), question));
			canvas.add(ans2Button);
			
			ans3Button = new JButton("３．" + question.getDispAns3().getDispAns());
			ans3Button.setHorizontalAlignment(JButton.LEFT);
			ans3Button.setFont(new Font("Meiryo UI", Font.BOLD, 13));
			ans3Button.setBounds(50, 200, 250, 40);
			ans3Button.addActionListener((e) -> selectAns(question.getDispAns3(), question));
			canvas.add(ans3Button);
			
			ans4Button = new JButton("４．" + question.getDispAns4().getDispAns());
			ans4Button.setHorizontalAlignment(JButton.LEFT);
			ans4Button.setFont(new Font("Meiryo UI", Font.BOLD, 13));
			ans4Button.setBounds(350, 200, 250, 40);
			ans4Button.addActionListener((e) -> selectAns(question.getDispAns4(), question));
			canvas.add(ans4Button);
			
		}
			
		// 次に行くボタンの設定をする。
		if(list.size() < maxNumQue) {
			// 最終問題以外の場合
			nextButton = new JButton("次の問題へ");
			nextButton.setFont(new Font("Century", Font.ITALIC, 13));
			nextButton.setBounds(650, 380, 100, 40);
			nextButton.setOpaque(true);
			nextButton.setBackground(Color.ORANGE);
			nextButton.addActionListener((e) -> selectNextQue());
			canvas.add(nextButton);
			
			anserButton = new JButton("正解を表示する");
			anserButton.setFont(new Font("Century", Font.ITALIC, 13));
			anserButton.setBounds(450, 380, 150, 40);
			anserButton.setOpaque(true);
			anserButton.setBackground(Color.ORANGE);
			anserButton.addActionListener((e) -> selectAns(null, question));
			canvas.add(anserButton);
			
		}else {
			//最終問題の場合
			nextButton = new JButton("結果表示へ");
			nextButton.setFont(new Font("Century", Font.ITALIC, 13));
			nextButton.setBounds(650, 380, 100, 40);
			nextButton.setOpaque(true);
			nextButton.setBackground(Color.ORANGE);
			nextButton.addActionListener((e) -> selectRslt());
			canvas.add(nextButton);
			
			anserButton = new JButton("正解を表示する");
			anserButton.setFont(new Font("Century", Font.ITALIC, 13));
			anserButton.setBounds(450, 380, 150, 40);
			anserButton.setOpaque(true);
			anserButton.setBackground(Color.ORANGE);
			anserButton.addActionListener((e) -> selectAns(null, question));
			canvas.add(anserButton);
			
		}
		
		// 画面にcanvasを追加
		pane.add(canvas);
		
	  }
	  
	  /**
	   * 解答を選んだ時の処理
	   *
	   * @param selected 選択した解答
	   * @param quetion 表示問題
	   */
	  public void selectAns(DispAns selected, QueAns quetion) {

	    // 入力待ちでなければ以降の処理はしない
	    if (playState != Status.Wait) {
	      return;
	    }
	    
	    ans1Button.setEnabled(false);
	    ans2Button.setEnabled(false);
	    ans3Button.setEnabled(false);
	    ans4Button.setEnabled(false);
	    anserButton.setEnabled(false);

	    // 解答の正否判定
	   if(!Objects.isNull(selected) && selected.getNumber() == quetion.getAns()) {
	        // 正解の場合、正答数を+1する。
		   numAns++;
	   }
	   
	   if(Objects.isNull(selected)) {
		   // 正解表示ボタンを押下した場合
		   anserLabel.setText(String.format("     正解：%1s", quetion.getAns()));
		   anserLabel.setOpaque(true);
		   anserLabel.setBackground(Color.GREEN);
		   
	   }else {
		   // 解答を選んで呼ばれた場合
		   anserLabel.setText(String.format("     正解：%1s    \"あなたの解答：%1s\"", quetion.getAns(), selected.getNumber()));
		   anserLabel.setOpaque(true);
		   anserLabel.setBackground(Color.GREEN);
	   }

	  }
	  
	  /**
	   * 次の問題へボタン押下時の処理
	   *
	   */
	  public void selectNextQue() {
		  
		canvas.removeAll();
		canvas.repaint();
		
		if(list.size() < maxNumQue) {
			// 問題を出題する。
			proposingQuestion(canvas, pane);
		}
		
	  }
	  
	  /**
	   * 結果表示へボタン押下時の処理
	   *
	   */
	  public void selectRslt() {
		  
		canvas.removeAll();
		canvas.repaint();
		
		// 解答の結果を表示する。
		rsltLabel = new JLabel(String.format("%2s問中%2s問正解しました。", list.size(), numAns));
		rsltLabel.setHorizontalAlignment(JLabel.CENTER);
		rsltLabel.setFont(new Font("Meiryo UI", Font.BOLD, 50));
		rsltLabel.setBounds(20, 60, 750, 50);
		canvas.add(rsltLabel);
		
		retryButton = new JButton("もう一度挑戦");
		retryButton.setFont(new Font("Century", Font.ITALIC, 20));
		retryButton.setBounds(250, 200, 250, 40);
		retryButton.addActionListener((e) -> selectStart());
		canvas.add(retryButton);
		
	  }
	  
	  public void selectStart() {
		  
		canvas.removeAll();
		canvas.repaint();
		
		// 出題した問題のリストをクリアする。
		list.clear();
		
		// 正答数のリセット
		numAns = 0;
		
		// 問題を出題する。
		proposingQuestion(canvas, pane);
	}

	
}
