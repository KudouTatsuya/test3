package create;

import create.window.MainWindow;

/*	改訂履歴
 * ----------- ------- --------------- ----------------
 * Date			Seq		Editor			Description
 * ----------- ------- --------------- ----------------
 * 2022-09-06	r1.00	T.Kudou			新規作成
 * 
 */

public class Main {

	public static void main(String[] args) {

		//ゲームウィンドウの生成と表示
		MainWindow window = new MainWindow();
		window.show();

	}

}
